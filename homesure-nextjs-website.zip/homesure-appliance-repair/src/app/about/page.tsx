import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "About Home Sure Appliance Repair | Texas Appliance Repair Experts",
  description: "Learn about Home Sure Appliance Repair — Texas's trusted appliance repair company. Certified technicians, same-day service, all major brands.",
};

export default function AboutPage() {
  return (
    <>
      <div className="about-hero">
        <h1>About Home Sure Appliance Repair</h1>
        <p>Serving Texas homeowners with honest, expert appliance repair since 2025.</p>
      </div>

      <section>
        <div className="section-inner">
          <div className="stats-grid">
            <div className="stat-card"><div className="stat-num">14+</div><div className="stat-label">Appliance Services</div></div>
            <div className="stat-card"><div className="stat-num">30+</div><div className="stat-label">Texas Cities Served</div></div>
            <div className="stat-card"><div className="stat-num">7AM–9PM</div><div className="stat-label">Daily Availability</div></div>
            <div className="stat-card"><div className="stat-num">100%</div><div className="stat-label">Satisfaction Goal</div></div>
          </div>
        </div>
      </section>

      <section className="bg-gray">
        <div className="section-inner">
          <div className="contact-grid">
            <div>
              <h2 className="section-title" style={{textAlign:'left'}}>Our Story</h2>
              <p>Home Sure Appliance Repair was founded in 2025 with a simple mission: provide Texas homeowners with reliable, transparent appliance repair they can trust. We know what Texas conditions — the intense heat, hard water, and frequent storms — do to home appliances.</p>
              <p>Our team of certified technicians is trained on all major brands including Whirlpool, GE, Samsung, LG, Frigidaire, Bosch, and premium brands like Sub-Zero, Wolf, and Thermador. We arrive equipped with OEM parts and professional diagnostic tools to resolve most issues in a single visit.</p>
              <p>We serve all of Texas — from Houston to El Paso, from Dallas to Corpus Christi — with the same commitment to quality and honest pricing.</p>
              <h3>Our Commitment</h3>
              <p>Every technician on our team undergoes rigorous training and carries liability insurance. We provide upfront pricing before any work begins — no surprise charges, no hidden fees. Our repairs are backed by a parts and labor warranty.</p>
            </div>
            <div className="info-block">
              <h3>Contact Information</h3>
              <div className="info-row">
                <div className="info-icon">📞</div>
                <div><strong>Phone</strong><br/><a href="tel:8776701060">(877) 670-1060</a></div>
              </div>
              <div className="info-row">
                <div className="info-icon">📧</div>
                <div><strong>Email</strong><br/><a href="mailto:info@homesureappliancerepair.us">info@homesureappliancerepair.us</a></div>
              </div>
              <div className="info-row">
                <div className="info-icon">📍</div>
                <div><strong>Address</strong><br/>4521 Westview Drive, Austin, TX 78731</div>
              </div>
              <div className="info-row">
                <div className="info-icon">⏰</div>
                <div><strong>Hours</strong><br/>7AM–9PM, 7 Days a Week</div>
              </div>
              <div style={{marginTop:'24px'}}>
                <a href="tel:8776701060" className="btn-primary" style={{display:'inline-flex'}}>📞 Call for Free Quote</a>
              </div>
            </div>
          </div>
        </div>
      </section>

      <div className="map-section">
        <iframe
  src="https://maps.google.com/maps?q=4521+Westview+Drive,+Austin,+TX+78731&output=embed&z=14"
  width="100%" height="420" style={{border:0,borderRadius:'8px'}}
  allowFullScreen loading="lazy"
  referrerPolicy="no-referrer-when-downgrade"
  title="Map"
></iframe>
      </div>
    </>
  );
}
