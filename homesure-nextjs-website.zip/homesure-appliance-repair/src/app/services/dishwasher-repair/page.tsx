import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Dishwasher Repair in Texas | Home Sure Appliance Repair | (877) 670-1060",
  description: "Professional dishwasher repair in Texas. Same-day service, all major brands. Licensed & insured technicians. Call (877) 670-1060 for a free quote.",
  openGraph: {
    title: "Dishwasher Repair in Texas | Home Sure Appliance Repair",
    description: "Professional dishwasher repair in Texas. Same-day service, all major brands.",
    url: "https://homesureappliancerepair.us/services/dishwasher-repair",
    images: [{ url: "https://images.pexels.com/photos/3829560/pexels-photo-3829560.jpeg?auto=compress&cs=tinysrgb&w=1200" }],
  },
};

export default function DishwasherRepairPage() {
  const schema = "{\"@context\": \"https://schema.org\", \"@type\": \"Service\", \"name\": \"Dishwasher Repair\", \"provider\": {\"@type\": \"LocalBusiness\", \"name\": \"Home Sure Appliance Repair\", \"telephone\": \"(877) 670-1060\", \"address\": {\"@type\": \"PostalAddress\", \"addressRegion\": \"TX\", \"addressCountry\": \"US\"}}, \"areaServed\": \"Texas\", \"description\": \"A malfunctioning dishwasher means piles of dishes and wasted time. From drainage failures to heating element problems, Home Sure Appliance Repair resolves dishwasher issues efficiently across Texas.\"}";
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schema }} />

      <div className="page-hero">
        <img src="https://images.pexels.com/photos/3829560/pexels-photo-3829560.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Dishwasher Repair in Texas" className="page-hero-img" width="1200" height="380" />
        <div className="page-hero-overlay" />
        <div className="page-hero-content">
          <div className="breadcrumb"><a href="/">Home</a> › <a href="/services/refrigerator-repair">Services</a> › Dishwasher Repair</div>
          <h1>Dishwasher Repair in Texas</h1>
          <p>Fast, professional service by certified technicians — available 7AM–9PM, 7 days a week.</p>
        </div>
      </div>

      {/* TOP CTA */}
      <div style={{ background: 'var(--accent-light)', padding: '20px', textAlign: 'center' }}>
        <strong>Need Dishwasher Repair Today?</strong> Call <a href="tel:8776701060" style={{ color: 'var(--primary)', fontWeight: 800, fontSize: '1.1rem' }}>📞 (877) 670-1060</a> — Same-Day Service Available
      </div>

      <div className="page-content">
        <h2>Professional Dishwasher Repair Across Texas</h2>
        <p>A malfunctioning dishwasher means piles of dishes and wasted time. From drainage failures to heating element problems, Home Sure Appliance Repair resolves dishwasher issues efficiently across Texas.</p>
        <p>Our technicians are trained on all major brands including KitchenAid, Samsung, LG, GE, Frigidaire. We arrive with a fully stocked service vehicle so most repairs are completed in a single visit, minimizing disruption to your home or business.</p>

        <h2>Common Dishwasher Repair Issues We Fix</h2>
        <div className="services-2col">
              <div className="service-item">✓ Not draining after cycle</div>
              <div className="service-item">✓ Not cleaning dishes properly</div>
              <div className="service-item">✓ Door latch or seal problems</div>
              <div className="service-item">✓ Control panel not responding</div>
              <div className="service-item">✓ Water not heating</div>
              <div className="service-item">✓ Leaking from the door or bottom</div>
              <div className="service-item">✓ Strange noises during operation</div>
              <div className="service-item">✓ Not filling with water</div>
        </div>

        <h2>Our Dishwasher Repair Process</h2>
        <p>We inspect the pump, drain hose, spray arms, door gasket, and heating element. Texas hard water often causes mineral buildup — we address this during service. Common brands we service include Bosch, Whirlpool, KitchenAid, Miele, and Samsung.</p>

        <img src="https://images.pexels.com/photos/8774376/pexels-photo-8774376.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Dishwasher Repair service in Texas" className="content-img" width="800" height="320" loading="lazy" />

        <h2>Why Texas Homeowners Choose Home Sure</h2>
        <p>Since 2025, Home Sure Appliance Repair has served Texas homeowners with honest, transparent service. We know the Texas climate — from the scorching heat of West Texas to the humid Gulf Coast — takes a toll on appliances. Our technicians understand these regional factors and account for them during every service call.</p>
        <p>We service brands including Miele, GE, LG, Frigidaire, Whirlpool, Bosch, and our technicians receive ongoing training to stay current with the latest appliance technologies. Whether you have a standard unit or a premium luxury appliance, we have the expertise and parts to fix it right.</p>
        <h3>Brands We Commonly Service</h3>
        <p>Our repair specialists are experienced with GE, Samsung, Thermador, LG, Miele, Bosch, KitchenAid, Whirlpool. If you don't see your brand listed, call (877) 670-1060 — we most likely service it.</p>
        <h3>Transparent Pricing</h3>
        <p>We provide a clear, written estimate before any work begins. Our pricing is competitive for the Texas market, and we never add hidden fees. The $$ price range reflects our commitment to fair, middle-market pricing for quality service.</p>
        <h3>Service Guarantee</h3>
        <p>Every repair comes with a parts and labor warranty. If the issue recurs within the warranty period, we'll return and correct it at no additional charge. Your satisfaction is our commitment.</p>

        <div className="cta-box">
  <h2>Schedule Your Dishwasher Repair Today</h2>
  <p>Call Home Sure Appliance Repair for fast, reliable service across Texas. Free quotes, same-day appointments available.</p>
  <a href="tel:8776701060" className="cta-phone">📞 (877) 670-1060</a>
  <p className="cta-hours">Available 7AM–9PM · 7 Days a Week</p>
  <div className="cta-badges">
    <span className="cta-badge">✓ Free Quote</span>
    <span className="cta-badge">✓ Same-Day Service</span>
    <span className="cta-badge">✓ Licensed & Insured</span>
  </div>
</div>

        <h2>Frequently Asked Questions — Dishwasher Repair</h2>
        <div className="faq-list">
    <div className="faq-item">
      <div className="faq-q">
        <span>What are the most common dishwasher repair problems you repair?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Common issues include: Not draining after cycle, Not cleaning dishes properly, Door latch or seal problems, Control panel not responding. Call (877) 670-1060 to describe your issue and we'll give you an upfront quote.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>How long does a dishwasher repair typically take?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Most dishwasher repair appointments take 1–2 hours. If parts need to be ordered, we'll let you know the estimated timeline. Our goal is always to complete the repair in a single visit.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Is it worth repairing my dishwasher?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>As a general rule, if the repair cost is less than 50% of the cost of a new unit and your appliance is under 10 years old, repair is usually the better choice. Our technicians will give you an honest recommendation.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Do you repair dishwashers of all brands?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Yes! We service all major brands including Bosch, Whirlpool, Miele, KitchenAid, Samsung. Call (877) 670-1060 to confirm service for your specific model.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Do you offer free estimates?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Yes! Home Sure Appliance Repair provides free diagnostic quotes before any work begins. Call (877) 670-1060 and we'll send a technician to assess the issue at no charge.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>What areas of Texas do you serve?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>We serve all major Texas cities including Houston, Dallas, Austin, San Antonio, Fort Worth, El Paso, and dozens more. Call (877) 670-1060 to confirm coverage in your area.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Are you available on weekends and holidays?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Absolutely. We're open 7AM–9PM, seven days a week including holidays. Appliance breakdowns don't follow a schedule, and neither do we.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Do your repairs come with a warranty?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Yes. All parts and labor are backed by our service warranty. If the repaired component fails within the warranty period, we'll return and fix it at no additional charge.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>What should I do if my appliance is leaking or smoking?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>If your appliance is smoking, sparking, or causing a gas smell, turn it off at the breaker or gas shutoff immediately and call us at (877) 670-1060. Do not use the appliance until it has been inspected.</p></div>
    </div>
</div>

        <h2>Customer Reviews</h2>
        <div className="reviews-grid">
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"My refrigerator stopped cooling on a hot Texas afternoon. Home Sure had a tech at my door within hours. Fast, professional, and fairly priced!"</p>
    <div className="review-author">James R.</div>
    <div className="review-location">Texas</div>
  </div>
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"The washer stopped spinning mid-cycle. Called at 8 AM, tech arrived by noon. Fixed on the spot. Couldn't be happier with the service."</p>
    <div className="review-author">Maria L.</div>
    <div className="review-location">Texas</div>
  </div>
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"Excellent work on our dishwasher. The technician explained everything clearly and had the parts ready. Highly recommend for any appliance issue."</p>
    <div className="review-author">David K.</div>
    <div className="review-location">Texas</div>
  </div>
</div>

        <h2>Related Services</h2>
        <div className="related-grid">
            <a href="/services/refrigerator-repair" className="related-link">Refrigerator Repair</a>
            <a href="/services/dryer-repair" className="related-link">Dryer Repair</a>
            <a href="/services/range-repair" className="related-link">Range Repair</a>
            <a href="/services/oven-repair" className="related-link">Oven Repair</a>
            <a href="/services/washer-repair" className="related-link">Washer Repair</a>
        </div>

        <h2>Cities We Serve</h2>
        <div className="related-grid">
            <a href="/cities/houston" className="related-link">Houston Appliance Repair</a>
            <a href="/cities/san-antonio" className="related-link">San Antonio Appliance Repair</a>
            <a href="/cities/dallas" className="related-link">Dallas Appliance Repair</a>
            <a href="/cities/austin" className="related-link">Austin Appliance Repair</a>
            <a href="/cities/fort-worth" className="related-link">Fort Worth Appliance Repair</a>
        </div>

        <h2>Related Articles</h2>
        <div className="related-grid">
            <a href="/blog/refrigerator-not-cooling-texas" className="related-link">Refrigerator Not Cooling in Texas Heat? Causes and Fixes</a>
            <a href="/blog/dishwasher-not-draining-texas" className="related-link">Dishwasher Not Draining? Texas Troubleshooting Guide</a>
            <a href="/blog/dryer-not-heating-texas" className="related-link">Dryer Not Heating? Common Problems in Texas Homes</a>
        </div>
      </div>

      <div className="map-section">
        <iframe
  src="https://maps.google.com/maps?q=Austin,+Texas&output=embed&z=14"
  width="100%" height="420" style={{border:0,borderRadius:'8px'}}
  allowFullScreen loading="lazy"
  referrerPolicy="no-referrer-when-downgrade"
  title="Map"
></iframe>
      </div>
    </>
  );
}
