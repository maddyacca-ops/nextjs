import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Appliance Repair Texas | Home Sure Appliance Repair | (877) 670-1060",
  description: "Expert appliance repair across Texas. Same-day service for refrigerators, washers, dryers, ovens & more. Licensed & insured. Call (877) 670-1060 for a free quote.",
  openGraph: {
    title: "Appliance Repair Texas | Home Sure Appliance Repair",
    description: "Expert appliance repair across Texas. Same-day service. Licensed & insured technicians.",
    url: "https://homesureappliancerepair.us",
    siteName: "Home Sure Appliance Repair",
    images: [{ url: "https://images.pexels.com/photos/33755641/pexels-photo-33755641.jpeg?auto=compress&cs=tinysrgb&w=1200" }],
    type: "website",
  },
  twitter: { card: "summary_large_image", title: "Appliance Repair Texas | Home Sure", description: "Expert appliance repair across Texas." },
};

export default function HomePage() {
  const faqSchema = "{\"@context\": \"https://schema.org\", \"@type\": \"FAQPage\", \"mainEntity\": [{\"@type\": \"Question\", \"name\": \"What appliances do you repair?\", \"acceptedAnswer\": {\"@type\": \"Answer\", \"text\": \"Home Sure Appliance Repair repairs all major household appliances including refrigerators, washers, dryers, ovens, ranges, dishwashers, freezers, ice makers, garbage disposals, microwaves, and commercial equipment throughout Texas.\"}}, {\"@type\": \"Question\", \"name\": \"How quickly can you come to my home?\", \"acceptedAnswer\": {\"@type\": \"Answer\", \"text\": \"We offer same-day and next-day service across Texas. In most major cities, we can dispatch a technician within 2\\u20134 hours of your call.\"}}, {\"@type\": \"Question\", \"name\": \"Do you service all appliance brands?\", \"acceptedAnswer\": {\"@type\": \"Answer\", \"text\": \"Yes! Our certified technicians are trained to repair all major brands including Whirlpool, GE, Samsung, LG, Frigidaire, Bosch, Maytag, KitchenAid, and many more.\"}}, {\"@type\": \"Question\", \"name\": \"What are your service hours?\", \"acceptedAnswer\": {\"@type\": \"Answer\", \"text\": \"We're available 7AM\\u20139PM, seven days a week, including holidays. Call (877) 670-1060 to schedule.\"}}, {\"@type\": \"Question\", \"name\": \"Do you offer warranties on repairs?\", \"acceptedAnswer\": {\"@type\": \"Answer\", \"text\": \"Yes, all our parts and labor come with a warranty. We stand behind our work and will make it right if any issues arise after our service.\"}}]}";
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: faqSchema }} />

      {/* HERO */}
      <section className="hero">
        <div className="hero-bg" style={{ backgroundImage: 'url("https://images.pexels.com/photos/33755641/pexels-photo-33755641.jpeg?auto=compress&cs=tinysrgb&w=1200")' }} />
        <div className="hero-content">
          <h1>Expert Appliance Repair Across Texas — Fast & Reliable</h1>
          <p>Same-day service for refrigerators, washers, dryers, ovens, and more. Whirlpool, GE, Samsung, LG — we fix all major brands.</p>
          <div className="hero-btns">
            <a href="tel:8776701060" className="btn-primary">📞 Call (877) 670-1060</a>
            <a href="/services/refrigerator-repair" className="btn-secondary">View Services</a>
          </div>
          <div className="trust-pills">
            <span className="trust-pill">✓ Same-Day Service</span>
            <span className="trust-pill">✓ Licensed & Insured</span>
            <span className="trust-pill">✓ Free Quote</span>
            <span className="trust-pill">✓ All Major Brands</span>
          </div>
        </div>
      </section>

      {/* TRUST BAR */}
      <div className="trust-bar">
        <div className="trust-bar-inner">
          <div className="trust-item">⚡ Same-Day Service</div>
          <div className="trust-item">🔒 Licensed & Insured</div>
          <div className="trust-item">💬 Free Quotes</div>
          <div className="trust-item">🛠 All Major Brands</div>
          <div className="trust-item">📍 Statewide Texas Coverage</div>
        </div>
      </div>

      {/* SERVICES */}
      <section>
        <div className="section-inner">
          <h2 className="section-title">Appliance Repair Services in Texas</h2>
          <p className="section-sub">Our certified technicians handle all major appliance repairs — residential and commercial — across the Lone Star State.</p>
          <div className="cards-grid">
        <div className="card">
          <img src="https://images.pexels.com/photos/33755641/pexels-photo-33755641.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Refrigerator Repair in Texas" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Refrigerator Repair</h3>
            <p>Fast, affordable refrigerator repair by certified technicians across Texas.</p>
            <a href="/services/refrigerator-repair" className="card-link">Learn More →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/3829560/pexels-photo-3829560.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Dishwasher Repair in Texas" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Dishwasher Repair</h3>
            <p>Fast, affordable dishwasher repair by certified technicians across Texas.</p>
            <a href="/services/dishwasher-repair" className="card-link">Learn More →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/8774376/pexels-photo-8774376.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Dryer Repair in Texas" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Dryer Repair</h3>
            <p>Fast, affordable dryer repair by certified technicians across Texas.</p>
            <a href="/services/dryer-repair" className="card-link">Learn More →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/3768169/pexels-photo-3768169.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Range Repair in Texas" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Range Repair</h3>
            <p>Fast, affordable range repair by certified technicians across Texas.</p>
            <a href="/services/range-repair" className="card-link">Learn More →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/4119841/pexels-photo-4119841.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Oven Repair in Texas" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Oven Repair</h3>
            <p>Fast, affordable oven repair by certified technicians across Texas.</p>
            <a href="/services/oven-repair" className="card-link">Learn More →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/8774444/pexels-photo-8774444.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Washer Repair in Texas" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Washer Repair</h3>
            <p>Fast, affordable washer repair by certified technicians across Texas.</p>
            <a href="/services/washer-repair" className="card-link">Learn More →</a>
          </div>
        </div>
            <div className="card" style={{ background: 'var(--primary)', color: 'white', display: 'flex', alignItems: 'center', justifyContent: 'center', flexDirection: 'column', padding: '32px', textAlign: 'center', minHeight: '200px' }}>
              <div style={{ fontSize: '2rem', marginBottom: '12px' }}>🔧</div>
              <h3 style={{ color: 'white', fontFamily: 'var(--font-display)', fontSize: '1.4rem', marginBottom: '8px' }}>All 14 Services</h3>
              <p style={{ color: 'rgba(255,255,255,0.85)', marginBottom: '16px' }}>See our full list of appliance repair services in Texas.</p>
              <a href="/cities" style={{ background: 'white', color: 'var(--primary)', padding: '10px 20px', borderRadius: '8px', fontWeight: 700 }}>View All Services →</a>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="bg-gray">
        <div className="section-inner">
          <div className="cta-box">
  <h2>Need Appliance Repair Today?</h2>
  <p>Call Home Sure Appliance Repair for fast, reliable service across Texas. Free quotes, same-day appointments available.</p>
  <a href="tel:8776701060" className="cta-phone">📞 (877) 670-1060</a>
  <p className="cta-hours">Available 7AM–9PM · 7 Days a Week</p>
  <div className="cta-badges">
    <span className="cta-badge">✓ Free Quote</span>
    <span className="cta-badge">✓ Same-Day Service</span>
    <span className="cta-badge">✓ Licensed & Insured</span>
  </div>
</div>
        </div>
      </section>

      {/* WHY US */}
      <section>
        <div className="section-inner">
          <h2 className="section-title">Why Texas Homeowners Trust Home Sure</h2>
          <p className="section-sub">We've built our reputation on honest, transparent service across Texas communities.</p>
          <div className="cards-grid">
            <div className="card" style={{ padding: '32px' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '14px' }}>⚡</div>
              <div className="card-body" style={{ padding: 0 }}>
                <h3>Same-Day Response</h3>
                <p>A broken appliance disrupts your life. We dispatch technicians fast — often within 2–4 hours of your call in major Texas cities.</p>
              </div>
            </div>
            <div className="card" style={{ padding: '32px' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '14px' }}>🎓</div>
              <div className="card-body" style={{ padding: 0 }}>
                <h3>Certified Technicians</h3>
                <p>All our technicians are factory-trained and certified to repair brands like Whirlpool, GE, Samsung, LG, Bosch, and many more.</p>
              </div>
            </div>
            <div className="card" style={{ padding: '32px' }}>
              <div style={{ fontSize: '2.5rem', marginBottom: '14px' }}>💰</div>
              <div className="card-body" style={{ padding: '0' }}>
                <h3>Upfront Pricing</h3>
                <p>No surprise charges. We diagnose the issue and give you a clear quote before starting any work. Competitive rates statewide.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SERVICE AREAS */}
      <section className="bg-gray">
        <div className="section-inner">
          <h2 className="section-title">Appliance Repair Across Texas</h2>
          <p className="section-sub">We serve homeowners and businesses throughout the Lone Star State.</p>
          <p style={{ textAlign: 'center', lineHeight: 2, fontSize: '0.95rem' }}>
            <a href="/cities/houston">Houston</a> · <a href="/cities/san-antonio">San Antonio</a> · <a href="/cities/dallas">Dallas</a> · <a href="/cities/austin">Austin</a> · <a href="/cities/fort-worth">Fort Worth</a> · <a href="/cities/el-paso">El Paso</a> · <a href="/cities/arlington">Arlington</a> · <a href="/cities/corpus-christi">Corpus Christi</a> · <a href="/cities/plano">Plano</a> · <a href="/cities/laredo">Laredo</a> · <a href="/cities/lubbock">Lubbock</a> · <a href="/cities/garland">Garland</a>
          </p>
          <div style={{ textAlign: 'center', marginTop: '28px' }}>
            <a href="/cities" className="btn-primary" style={{ display: 'inline-flex' }}>View All Texas Cities →</a>
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section>
        <div className="section-inner">
          <h2 className="section-title">What Texas Homeowners Say</h2>
          <p className="section-sub">Real reviews from real customers across the Lone Star State.</p>
          <div className="reviews-grid">
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"My refrigerator stopped cooling on a hot Texas afternoon. Home Sure had a tech at my door within hours. Fast, professional, and fairly priced!"</p>
    <div className="review-author">James R.</div>
    <div className="review-location">Texas</div>
  </div>
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"The washer stopped spinning mid-cycle. Called at 8 AM, tech arrived by noon. Fixed on the spot. Couldn't be happier with the service."</p>
    <div className="review-author">Maria L.</div>
    <div className="review-location">Texas</div>
  </div>
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"Excellent work on our dishwasher. The technician explained everything clearly and had the parts ready. Highly recommend for any appliance issue."</p>
    <div className="review-author">David K.</div>
    <div className="review-location">Texas</div>
  </div>
</div>
        </div>
      </section>

      {/* BLOG */}
      <section className="bg-gray">
        <div className="section-inner">
          <h2 className="section-title">Expert Appliance Repair Tips for Texas Residents</h2>
          <p className="section-sub">Practical advice to help you understand, troubleshoot, and maintain your home appliances.</p>
          <div className="cards-grid">
        <div className="card">
          <img src="https://images.pexels.com/photos/33755641/pexels-photo-33755641.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Refrigerator Not Cooling in Texas Heat? Causes and Fixes" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Refrigerator Not Cooling in Texas Heat? Causes and Fixes</h3>
            <p className="blog-date">January 07, 2026</p>
            <a href="/blog/refrigerator-not-cooling-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/3829560/pexels-photo-3829560.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Dishwasher Not Draining? Texas Troubleshooting Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Dishwasher Not Draining? Texas Troubleshooting Guide</h3>
            <p className="blog-date">January 14, 2026</p>
            <a href="/blog/dishwasher-not-draining-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/8774376/pexels-photo-8774376.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Dryer Not Heating? Common Problems in Texas Homes" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <h3>Dryer Not Heating? Common Problems in Texas Homes</h3>
            <p className="blog-date">January 21, 2026</p>
            <a href="/blog/dryer-not-heating-texas" className="card-link">Read Article →</a>
          </div>
        </div>
          </div>
          <div style={{ textAlign: 'center', marginTop: '32px' }}>
            <a href="/blog" className="btn-primary" style={{ display: 'inline-flex' }}>View All Articles →</a>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section>
        <div className="section-inner">
          <h2 className="section-title">Frequently Asked Questions</h2>
          <div className="faq-list">
    <div className="faq-item">
      <div className="faq-q">
        <span>What appliances do you repair?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Home Sure Appliance Repair repairs all major household appliances including refrigerators, washers, dryers, ovens, ranges, dishwashers, freezers, ice makers, garbage disposals, microwaves, and commercial equipment throughout Texas.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>How quickly can you come to my home?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>We offer same-day and next-day service across Texas. In most major cities, we can dispatch a technician within 2–4 hours of your call.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Do you service all appliance brands?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Yes! Our certified technicians are trained to repair all major brands including Whirlpool, GE, Samsung, LG, Frigidaire, Bosch, Maytag, KitchenAid, and many more.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>What are your service hours?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>We're available 7AM–9PM, seven days a week, including holidays. Call (877) 670-1060 to schedule.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Do you offer warranties on repairs?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Yes, all our parts and labor come with a warranty. We stand behind our work and will make it right if any issues arise after our service.</p></div>
    </div>
</div>
        </div>
      </section>

      {/* MAP */}
      <div className="map-section">
        <iframe
  src="https://maps.google.com/maps?q=4521+Westview+Drive,+Austin,+TX+78731&output=embed&z=14"
  width="100%" height="420" style={{border:0,borderRadius:'8px'}}
  allowFullScreen loading="lazy"
  referrerPolicy="no-referrer-when-downgrade"
  title="Map"
></iframe>
      </div>
    </>
  );
}
