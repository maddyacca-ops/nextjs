import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Appliance Repair Cities in Texas | Home Sure Appliance Repair",
  description: "Home Sure Appliance Repair serves all major Texas cities. Find appliance repair service in Houston, Dallas, Austin, San Antonio, and 25+ more cities.",
};

export default function CitiesIndexPage() {
  return (
    <>
      <div className="page-hero" style={{height:'240px'}}>
        <div className="page-hero-overlay"/>
        <div className="page-hero-content">
          <div className="breadcrumb"><a href="/">Home</a> › Service Areas</div>
          <h1>Appliance Repair Across Texas</h1>
          <p>We serve 30+ cities throughout the Lone Star State.</p>
        </div>
      </div>

      <section>
        <div className="section-inner">
          <h2 className="section-title">Texas Cities We Serve</h2>
          <p className="section-sub">Click your city to see local appliance repair services, coverage details, and contact information.</p>
          <div className="cities-grid">
        <a href="/cities/houston" className="city-card">
          <strong>Houston</strong>
          <span>Harris County · ZIP 77001</span>
        </a>
        <a href="/cities/san-antonio" className="city-card">
          <strong>San Antonio</strong>
          <span>Bexar County · ZIP 78201</span>
        </a>
        <a href="/cities/dallas" className="city-card">
          <strong>Dallas</strong>
          <span>Dallas County · ZIP 75201</span>
        </a>
        <a href="/cities/austin" className="city-card">
          <strong>Austin</strong>
          <span>Travis County · ZIP 78701</span>
        </a>
        <a href="/cities/fort-worth" className="city-card">
          <strong>Fort Worth</strong>
          <span>Tarrant County · ZIP 76101</span>
        </a>
        <a href="/cities/el-paso" className="city-card">
          <strong>El Paso</strong>
          <span>El Paso County · ZIP 79901</span>
        </a>
        <a href="/cities/arlington" className="city-card">
          <strong>Arlington</strong>
          <span>Tarrant County · ZIP 76001</span>
        </a>
        <a href="/cities/corpus-christi" className="city-card">
          <strong>Corpus Christi</strong>
          <span>Nueces County · ZIP 78401</span>
        </a>
        <a href="/cities/plano" className="city-card">
          <strong>Plano</strong>
          <span>Collin County · ZIP 75023</span>
        </a>
        <a href="/cities/laredo" className="city-card">
          <strong>Laredo</strong>
          <span>Webb County · ZIP 78040</span>
        </a>
        <a href="/cities/lubbock" className="city-card">
          <strong>Lubbock</strong>
          <span>Lubbock County · ZIP 79401</span>
        </a>
        <a href="/cities/garland" className="city-card">
          <strong>Garland</strong>
          <span>Dallas County · ZIP 75040</span>
        </a>
        <a href="/cities/irving" className="city-card">
          <strong>Irving</strong>
          <span>Dallas County · ZIP 75060</span>
        </a>
        <a href="/cities/amarillo" className="city-card">
          <strong>Amarillo</strong>
          <span>Potter County · ZIP 79101</span>
        </a>
        <a href="/cities/grand-prairie" className="city-card">
          <strong>Grand Prairie</strong>
          <span>Dallas County · ZIP 75050</span>
        </a>
        <a href="/cities/mckinney" className="city-card">
          <strong>McKinney</strong>
          <span>Collin County · ZIP 75069</span>
        </a>
        <a href="/cities/frisco" className="city-card">
          <strong>Frisco</strong>
          <span>Collin County · ZIP 75033</span>
        </a>
        <a href="/cities/pasadena" className="city-card">
          <strong>Pasadena</strong>
          <span>Harris County · ZIP 77501</span>
        </a>
        <a href="/cities/killeen" className="city-card">
          <strong>Killeen</strong>
          <span>Bell County · ZIP 76541</span>
        </a>
        <a href="/cities/mcallen" className="city-card">
          <strong>McAllen</strong>
          <span>Hidalgo County · ZIP 78501</span>
        </a>
        <a href="/cities/mesquite" className="city-card">
          <strong>Mesquite</strong>
          <span>Dallas County · ZIP 75149</span>
        </a>
        <a href="/cities/waco" className="city-card">
          <strong>Waco</strong>
          <span>McLennan County · ZIP 76701</span>
        </a>
        <a href="/cities/carrollton" className="city-card">
          <strong>Carrollton</strong>
          <span>Dallas County · ZIP 75006</span>
        </a>
        <a href="/cities/round-rock" className="city-card">
          <strong>Round Rock</strong>
          <span>Williamson County · ZIP 78664</span>
        </a>
        <a href="/cities/abilene" className="city-card">
          <strong>Abilene</strong>
          <span>Taylor County · ZIP 79601</span>
        </a>
        <a href="/cities/beaumont" className="city-card">
          <strong>Beaumont</strong>
          <span>Jefferson County · ZIP 77701</span>
        </a>
        <a href="/cities/midland" className="city-card">
          <strong>Midland</strong>
          <span>Midland County · ZIP 79701</span>
        </a>
        <a href="/cities/odessa" className="city-card">
          <strong>Odessa</strong>
          <span>Ector County · ZIP 79760</span>
        </a>
        <a href="/cities/tyler" className="city-card">
          <strong>Tyler</strong>
          <span>Smith County · ZIP 75701</span>
        </a>
        <a href="/cities/denton" className="city-card">
          <strong>Denton</strong>
          <span>Denton County · ZIP 76201</span>
        </a>
          </div>
          <div style={{textAlign:'center', marginTop:'40px'}}>
            <div className="cta-box">
  <h2>Don't See Your City? Call Us!</h2>
  <p>Call Home Sure Appliance Repair for fast, reliable service across Texas. Free quotes, same-day appointments available.</p>
  <a href="tel:8776701060" className="cta-phone">📞 (877) 670-1060</a>
  <p className="cta-hours">Available 7AM–9PM · 7 Days a Week</p>
  <div className="cta-badges">
    <span className="cta-badge">✓ Free Quote</span>
    <span className="cta-badge">✓ Same-Day Service</span>
    <span className="cta-badge">✓ Licensed & Insured</span>
  </div>
</div>
          </div>
        </div>
      </section>
    </>
  );
}
