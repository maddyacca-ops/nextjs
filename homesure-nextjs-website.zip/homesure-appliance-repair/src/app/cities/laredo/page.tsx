import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Appliance Repair Laredo, TX | Home Sure Appliance Repair | (877) 670-1060",
  description: "Expert appliance repair in Laredo, Texas. Same-day service for refrigerators, washers, dryers, ovens & more. Call (877) 670-1060 for a free quote.",
  openGraph: {
    title: "Appliance Repair Laredo, TX | Home Sure Appliance Repair",
    description: "Expert appliance repair in Laredo, Texas. Same-day service, all major brands.",
    url: "https://homesureappliancerepair.us/cities/laredo",
    images: [{ url: "https://images.pexels.com/photos/7285975/pexels-photo-7285975.jpeg?auto=compress&cs=tinysrgb&w=1200" }],
  },
};

export default function LaredoPage() {
  const schema = "{\"@context\": \"https://schema.org\", \"@type\": \"LocalBusiness\", \"name\": \"Home Sure Appliance Repair \\u2014 Laredo\", \"url\": \"https://homesureappliancerepair.us/cities/laredo\", \"telephone\": \"(877) 670-1060\", \"email\": \"info@homesureappliancerepair.us\", \"address\": {\"@type\": \"PostalAddress\", \"addressLocality\": \"Laredo\", \"addressRegion\": \"TX\", \"postalCode\": \"78040\", \"addressCountry\": \"US\"}, \"geo\": {\"@type\": \"GeoCoordinates\", \"latitude\": \"27.5306\", \"longitude\": \"-99.4803\"}, \"openingHours\": \"Mo-Su 07:00-21:00\", \"areaServed\": {\"@type\": \"City\", \"name\": \"Laredo\"}}";
  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: schema }} />

      <div className="page-hero">
        <img src="https://images.pexels.com/photos/7285975/pexels-photo-7285975.jpeg?auto=compress&cs=tinysrgb&w=1200" alt="Appliance Repair Laredo TX" className="page-hero-img" width="1200" height="380" />
        <div className="page-hero-overlay" />
        <div className="page-hero-content">
          <div className="breadcrumb"><a href="/">Home</a> › <a href="/cities">Service Areas</a> › Laredo</div>
          <h1>Appliance Repair in Laredo, Texas</h1>
          <p>Serving Laredo and Webb County — 7AM–9PM, 7 days a week. ZIP: 78040</p>
        </div>
      </div>

      <div style={{ background: 'var(--accent-light)', padding: '20px', textAlign: 'center' }}>
        <strong>Serving Laredo, TX?</strong> Call <a href="tel:8776701060" style={{ color: 'var(--primary)', fontWeight: 800, fontSize: '1.1rem' }}>📞 (877) 670-1060</a> — Same-Day Service Available
      </div>

      <div className="page-content">
        <h2>Professional Appliance Repair in Laredo, TX</h2>
        <p>Home Sure Appliance Repair provides comprehensive appliance repair services throughout Laredo and Webb County, Texas. Our certified technicians respond quickly to restore your refrigerators, washers, dryers, ovens, dishwashers, and more to full working order.</p>
        <p>Whether you're in the 78040 zip code or surrounding areas of Webb County, we dispatch trained technicians equipped with OEM parts for most major brands including Amana, Maytag, Whirlpool, Sub-Zero, Viking, Wolf.</p>

        <h2>Appliance Repairs We Offer in Laredo</h2>
        <div className="services-2col">
          <div className="service-item">✓ <a href="/services/refrigerator-repair">Refrigerator Repair</a></div>
          <div className="service-item">✓ <a href="/services/dishwasher-repair">Dishwasher Repair</a></div>
          <div className="service-item">✓ <a href="/services/dryer-repair">Dryer Repair</a></div>
          <div className="service-item">✓ <a href="/services/range-repair">Range Repair</a></div>
          <div className="service-item">✓ <a href="/services/oven-repair">Oven Repair</a></div>
          <div className="service-item">✓ <a href="/services/washer-repair">Washer Repair</a></div>
          <div className="service-item">✓ <a href="/services/freezer-repair">Freezer Repair</a></div>
          <div className="service-item">✓ <a href="/services/garbage-disposal-repair">Garbage Disposal Repair</a></div>
          <div className="service-item">✓ <a href="/services/ice-maker-repair">Ice Maker Repair</a></div>
          <div className="service-item">✓ <a href="/services/stove-repair">Stove Repair</a></div>
          <div className="service-item">✓ <a href="/services/washing-machine-repair">Washing Machine Repair</a></div>
          <div className="service-item">✓ <a href="/services/clothes-dryer-repair">Clothes Dryer Repair</a></div>
          <div className="service-item">✓ <a href="/services/microwave-repair">Microwave Repair</a></div>
          <div className="service-item">✓ <a href="/services/commercial-appliance-repair">Commercial Appliance Repair</a></div>
        </div>

        <img src="https://images.pexels.com/photos/32497160/pexels-photo-32497160.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Appliance repair technician in Laredo TX" className="content-img" width="800" height="320" loading="lazy" />

        <h2>How Laredo's Climate Affects Your Appliances</h2>
        <p>Laredo is located in Webb County, Texas, and like much of the Lone Star State, experiences intense heat, humidity variations, and hard water conditions that accelerate appliance wear. Refrigerators and freezers work overtime during Texas summers — leading to compressor strain and cooling inefficiency. Washers and dishwashers in Laredo face mineral buildup from hard water that clogs filters and damages pumps over time.</p>
        <p>Our Laredo technicians understand these regional challenges and proactively address them during every service visit. We recommend annual maintenance checks to extend appliance life — especially during peak summer months.</p>

        <h2>Brands We Service in Laredo</h2>
        <p>Our technicians in Laredo are factory-trained on all major appliance brands. We commonly service Samsung, Whirlpool, Sub-Zero, Maytag, Kenmore, KitchenAid, Thermador, Viking and many more. If you have a luxury brand like Sub-Zero, Wolf, or Thermador, we have the specialized training to handle it properly.</p>
        <h3>Appliance Brands Serviced</h3>
        <p>From everyday brands like Whirlpool, GE, and Maytag to premium manufacturers like Viking, Miele, and JennAir — our Laredo technicians carry the tools and parts to get the job done right, often in a single visit.</p>

        <div className="cta-box">
  <h2>Schedule Appliance Repair in Laredo Today</h2>
  <p>Call Home Sure Appliance Repair for fast, reliable service across Texas. Free quotes, same-day appointments available.</p>
  <a href="tel:8776701060" className="cta-phone">📞 (877) 670-1060</a>
  <p className="cta-hours">Available 7AM–9PM · 7 Days a Week</p>
  <div className="cta-badges">
    <span className="cta-badge">✓ Free Quote</span>
    <span className="cta-badge">✓ Same-Day Service</span>
    <span className="cta-badge">✓ Licensed & Insured</span>
  </div>
</div>

        <h2>Service Area Details — Laredo, TX</h2>
        <table className="zip-table">
          <thead><tr><th>City</th><th>ZIP Code</th><th>County</th></tr></thead>
          <tbody>
            <tr><td>Laredo</td><td>78040</td><td>Webb County</td></tr>
          </tbody>
        </table>

        <h2>Frequently Asked Questions — Laredo Appliance Repair</h2>
        <div className="faq-list">
    <div className="faq-item">
      <div className="faq-q">
        <span>How quickly can you reach Laredo, TX?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>In Laredo and Webb County, we typically dispatch within 2–4 hours. Call (877) 670-1060 and we'll give you an accurate arrival window.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>What zip codes do you serve in Laredo?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>We serve 78040 and surrounding zip codes throughout Laredo and Webb County. Call (877) 670-1060 to confirm coverage.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Do you service all appliance brands in Laredo?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Yes! Our Laredo technicians are trained on all major brands including KitchenAid, LG, Whirlpool, Sub-Zero, Wolf. Call us to confirm service for your specific model.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>What are your hours in Laredo, Texas?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>We serve Laredo 7AM–9PM daily, seven days a week including holidays.</p></div>
    </div>
    <div className="faq-item">
      <div className="faq-q">
        <span>Are your technicians licensed to work in Laredo, TX?</span>
        <svg className="faq-icon" viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg>
      </div>
      <div className="faq-a"><p>Yes. All Home Sure technicians are fully licensed and insured to perform appliance repairs in Laredo and throughout Webb County.</p></div>
    </div>
</div>

        <h2>Customer Reviews from Laredo</h2>
        <div className="reviews-grid">
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"My refrigerator stopped cooling on a hot Texas afternoon. Home Sure had a tech at my door within hours. Fast, professional, and fairly priced!"</p>
    <div className="review-author">James R.</div>
    <div className="review-location">Laredo, TX</div>
  </div>
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"The washer stopped spinning mid-cycle. Called at 8 AM, tech arrived by noon. Fixed on the spot. Couldn't be happier with the service."</p>
    <div className="review-author">Maria L.</div>
    <div className="review-location">Laredo, TX</div>
  </div>
  <div className="review-card">
    <div className="stars">★★★★★</div>
    <p className="review-text">"Excellent work on our dishwasher. The technician explained everything clearly and had the parts ready. Highly recommend for any appliance issue."</p>
    <div className="review-author">David K.</div>
    <div className="review-location">Laredo, TX</div>
  </div>
</div>

        <h2>Services Available in Laredo</h2>
        <div className="related-grid">
          <a href="/services/refrigerator-repair" className="related-link">Refrigerator Repair</a>
          <a href="/services/dishwasher-repair" className="related-link">Dishwasher Repair</a>
          <a href="/services/dryer-repair" className="related-link">Dryer Repair</a>
          <a href="/services/range-repair" className="related-link">Range Repair</a>
          <a href="/services/oven-repair" className="related-link">Oven Repair</a>
          <a href="/services/washer-repair" className="related-link">Washer Repair</a>
          <a href="/services/freezer-repair" className="related-link">Freezer Repair</a>
          <a href="/services/garbage-disposal-repair" className="related-link">Garbage Disposal Repair</a>
          <a href="/services/ice-maker-repair" className="related-link">Ice Maker Repair</a>
          <a href="/services/stove-repair" className="related-link">Stove Repair</a>
          <a href="/services/washing-machine-repair" className="related-link">Washing Machine Repair</a>
          <a href="/services/clothes-dryer-repair" className="related-link">Clothes Dryer Repair</a>
          <a href="/services/microwave-repair" className="related-link">Microwave Repair</a>
          <a href="/services/commercial-appliance-repair" className="related-link">Commercial Appliance Repair</a>
        </div>

        <h2>Nearby Cities We Also Serve</h2>
        <div className="related-grid">
          <a href="/cities/houston" className="related-link">Houston</a>
          <a href="/cities/san-antonio" className="related-link">San Antonio</a>
          <a href="/cities/dallas" className="related-link">Dallas</a>
          <a href="/cities/austin" className="related-link">Austin</a>
          <a href="/cities/fort-worth" className="related-link">Fort Worth</a>
        </div>

        <h2>Helpful Articles for Laredo Homeowners</h2>
        <div className="related-grid">
          <a href="/blog/refrigerator-not-cooling-texas" className="related-link">Refrigerator Not Cooling in Texas Heat? Causes and Fixes</a>
          <a href="/blog/dishwasher-not-draining-texas" className="related-link">Dishwasher Not Draining? Texas Troubleshooting Guide</a>
          <a href="/blog/dryer-not-heating-texas" className="related-link">Dryer Not Heating? Common Problems in Texas Homes</a>
        </div>
      </div>

      <div className="map-section">
        <iframe
  src="https://maps.google.com/maps?q=Appliance+Repair+Laredo+Texas&output=embed&z=14"
  width="100%" height="420" style={{border:0,borderRadius:'8px'}}
  allowFullScreen loading="lazy"
  referrerPolicy="no-referrer-when-downgrade"
  title="Map"
></iframe>
      </div>
    </>
  );
}
