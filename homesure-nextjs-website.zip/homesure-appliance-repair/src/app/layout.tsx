import type { Metadata } from "next";
import Link from "next/link";
import "./globals.css";

export const metadata: Metadata = {
  title: "Home Sure Appliance Repair | Expert Appliance Repair Across Texas",
  description: "Professional appliance repair in Texas. Same-day service for refrigerators, washers, dryers, ovens & more. Call (877) 670-1060 for a free quote.",
  metadataBase: new URL("https://homesureappliancerepair.us"),
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  const schema = "{\n  \"@context\": \"https://schema.org\",\n  \"@type\": \"LocalBusiness\",\n  \"name\": \"Home Sure Appliance Repair\",\n  \"url\": \"https://homesureappliancerepair.us\",\n  \"telephone\": \"(877) 670-1060\",\n  \"email\": \"info@homesureappliancerepair.us\",\n  \"address\": {\n    \"@type\": \"PostalAddress\",\n    \"streetAddress\": \"4521 Westview Drive\",\n    \"addressLocality\": \"Austin\",\n    \"addressRegion\": \"TX\",\n    \"postalCode\": \"78731\",\n    \"addressCountry\": \"US\"\n  },\n  \"geo\": {\n    \"@type\": \"GeoCoordinates\",\n    \"latitude\": \"30.3488\",\n    \"longitude\": \"-97.7612\"\n  },\n  \"openingHours\": \"Mo-Su 07:00-21:00\",\n  \"priceRange\": \"$$\",\n  \"areaServed\": \"Texas\",\n  \"sameAs\": [\n    \"https://www.instagram.com/homesureappliancerepair.us\",\n    \"https://www.facebook.com/profile.php?id=61573310241667\"\n  ],\n  \"foundingDate\": \"2025\"\n}";
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@600;700&family=Inter:wght@400;500;600&display=swap" rel="stylesheet" />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: schema }}
        />
      </head>
      <body>
        <div id="topbar">
          <div className="topbar-inner">
            <span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/></svg>
              <a href="tel:8776701060">(877) 670-1060</a>
            </span>
            <span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 14.5v-9l6 4.5-6 4.5z"/></svg>
              7AM–9PM Daily
            </span>
            <span>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
              4521 Westview Drive, Austin, TX 78731
            </span>
          </div>
        </div>

        <nav id="navbar">
          <div className="nav-inner">
            <Link href="/" className="nav-logo">
              <span className="logo-icon">🔧</span>
              <span className="logo-text">Home Sure<br/><small>Appliance Repair</small></span>
            </Link>
            <button className="hamburger" id="hamburger" aria-label="Menu">
              <span/><span/><span/>
            </button>
            <div className="nav-links" id="nav-links">
              <Link href="/">Home</Link>
              <div className="dropdown">
                <a href="#" className="dropdown-toggle">Services ▾</a>
                <div className="dropdown-menu">
              <Link href="/services/refrigerator-repair" className="dropdown-item">Refrigerator Repair</Link>
              <Link href="/services/dishwasher-repair" className="dropdown-item">Dishwasher Repair</Link>
              <Link href="/services/dryer-repair" className="dropdown-item">Dryer Repair</Link>
              <Link href="/services/range-repair" className="dropdown-item">Range Repair</Link>
              <Link href="/services/oven-repair" className="dropdown-item">Oven Repair</Link>
              <Link href="/services/washer-repair" className="dropdown-item">Washer Repair</Link>
              <Link href="/services/freezer-repair" className="dropdown-item">Freezer Repair</Link>
              <Link href="/services/garbage-disposal-repair" className="dropdown-item">Garbage Disposal Repair</Link>
              <Link href="/services/ice-maker-repair" className="dropdown-item">Ice Maker Repair</Link>
              <Link href="/services/stove-repair" className="dropdown-item">Stove Repair</Link>
              <Link href="/services/washing-machine-repair" className="dropdown-item">Washing Machine Repair</Link>
              <Link href="/services/clothes-dryer-repair" className="dropdown-item">Clothes Dryer Repair</Link>
              <Link href="/services/microwave-repair" className="dropdown-item">Microwave Repair</Link>
              <Link href="/services/commercial-appliance-repair" className="dropdown-item">Commercial Appliance Repair</Link>
                </div>
              </div>
              <div className="dropdown">
                <a href="#" className="dropdown-toggle">Service Areas ▾</a>
                <div className="dropdown-menu dropdown-menu-wide">
              <Link href="/cities/houston" className="dropdown-item">Houston</Link>
              <Link href="/cities/san-antonio" className="dropdown-item">San Antonio</Link>
              <Link href="/cities/dallas" className="dropdown-item">Dallas</Link>
              <Link href="/cities/austin" className="dropdown-item">Austin</Link>
              <Link href="/cities/fort-worth" className="dropdown-item">Fort Worth</Link>
              <Link href="/cities/el-paso" className="dropdown-item">El Paso</Link>
              <Link href="/cities/arlington" className="dropdown-item">Arlington</Link>
              <Link href="/cities/corpus-christi" className="dropdown-item">Corpus Christi</Link>
              <Link href="/cities/plano" className="dropdown-item">Plano</Link>
              <Link href="/cities/laredo" className="dropdown-item">Laredo</Link>
              <Link href="/cities/lubbock" className="dropdown-item">Lubbock</Link>
              <Link href="/cities/garland" className="dropdown-item">Garland</Link>
              <Link href="/cities/irving" className="dropdown-item">Irving</Link>
              <Link href="/cities/amarillo" className="dropdown-item">Amarillo</Link>
              <Link href="/cities/grand-prairie" className="dropdown-item">Grand Prairie</Link>
              <Link href="/cities/mckinney" className="dropdown-item">McKinney</Link>
              <Link href="/cities/frisco" className="dropdown-item">Frisco</Link>
              <Link href="/cities/pasadena" className="dropdown-item">Pasadena</Link>
                  <Link href="/cities" className="dropdown-item view-all">View All Cities →</Link>
                </div>
              </div>
              <Link href="/blog">Blog</Link>
              <Link href="/about">About</Link>
              <Link href="/contact">Contact</Link>
              <a href="tel:8776701060" className="btn-cta">Free Quote</a>
            </div>
          </div>
        </nav>

        <main>{children}</main>

        <footer id="footer">
          <div className="footer-inner">
            <div className="footer-col">
              <div className="footer-logo">🔧 Home Sure Appliance Repair</div>
              <p>Expert Appliance Repair Across Texas — Same-Day Service Available</p>
              <p>4521 Westview Drive, Austin, TX 78731</p>
              <p><a href="tel:8776701060">(877) 670-1060</a></p>
              <p><a href="mailto:info@homesureappliancerepair.us">info@homesureappliancerepair.us</a></p>
              <div className="social-icons">
                <a href="https://www.instagram.com/homesureappliancerepair.us" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>
                </a>
                <a href="https://www.facebook.com/profile.php?id=61573310241667" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor"><path d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg>
                </a>
              </div>
            </div>
            <div className="footer-col">
              <h4>Our Services</h4>
              <ul>
              <li><Link href="/services/refrigerator-repair">Refrigerator Repair</Link></li>
              <li><Link href="/services/dishwasher-repair">Dishwasher Repair</Link></li>
              <li><Link href="/services/dryer-repair">Dryer Repair</Link></li>
              <li><Link href="/services/range-repair">Range Repair</Link></li>
              <li><Link href="/services/oven-repair">Oven Repair</Link></li>
              <li><Link href="/services/washer-repair">Washer Repair</Link></li>
              <li><Link href="/services/freezer-repair">Freezer Repair</Link></li>
              <li><Link href="/services/garbage-disposal-repair">Garbage Disposal Repair</Link></li>
              <li><Link href="/services/ice-maker-repair">Ice Maker Repair</Link></li>
              <li><Link href="/services/stove-repair">Stove Repair</Link></li>
              <li><Link href="/services/washing-machine-repair">Washing Machine Repair</Link></li>
              <li><Link href="/services/clothes-dryer-repair">Clothes Dryer Repair</Link></li>
              <li><Link href="/services/microwave-repair">Microwave Repair</Link></li>
              <li><Link href="/services/commercial-appliance-repair">Commercial Appliance Repair</Link></li>
              </ul>
            </div>
            <div className="footer-col">
              <h4>Service Areas</h4>
              <ul>
              <li><Link href="/cities/houston">Houston</Link></li>
              <li><Link href="/cities/san-antonio">San Antonio</Link></li>
              <li><Link href="/cities/dallas">Dallas</Link></li>
              <li><Link href="/cities/austin">Austin</Link></li>
              <li><Link href="/cities/fort-worth">Fort Worth</Link></li>
              <li><Link href="/cities/el-paso">El Paso</Link></li>
              <li><Link href="/cities/arlington">Arlington</Link></li>
              <li><Link href="/cities/corpus-christi">Corpus Christi</Link></li>
              <li><Link href="/cities/plano">Plano</Link></li>
              <li><Link href="/cities/laredo">Laredo</Link></li>
              <li><Link href="/cities/lubbock">Lubbock</Link></li>
              <li><Link href="/cities/garland">Garland</Link></li>
                <li><Link href="/cities">View All Cities →</Link></li>
              </ul>
            </div>
            <div className="footer-col">
              <h4>Quick Links</h4>
              <ul>
                <li><Link href="/">Home</Link></li>
                <li><Link href="/about">About Us</Link></li>
                <li><Link href="/blog">Blog</Link></li>
                <li><Link href="/contact">Contact</Link></li>
                <li><Link href="/privacy">Privacy Policy</Link></li>
                <li><Link href="/terms">Terms of Service</Link></li>
              </ul>
            </div>
          </div>
          <div className="footer-bottom">
            <p>© {new Date().getFullYear()} Home Sure Appliance Repair. All Rights Reserved. | Licensed & Insured | Serving All of Texas</p>
          </div>
        </footer>

        <a href="tel:8776701060" className="float-cta" aria-label="Call Now">
          <svg width="28" height="28" viewBox="0 0 24 24" fill="currentColor"><path d="M6.6 10.8c1.4 2.8 3.8 5.1 6.6 6.6l2.2-2.2c.3-.3.7-.4 1-.2 1.1.4 2.3.6 3.6.6.6 0 1 .4 1 1V20c0 .6-.4 1-1 1-9.4 0-17-7.6-17-17 0-.6.4-1 1-1h3.5c.6 0 1 .4 1 1 0 1.3.2 2.5.6 3.6.1.3 0 .7-.2 1L6.6 10.8z"/></svg>
        </a>

        <script dangerouslySetInnerHTML={{ __html: `
          // Hamburger
          const ham = document.getElementById('hamburger');
          const navLinks = document.getElementById('nav-links');
          if(ham) ham.addEventListener('click', () => navLinks.classList.toggle('open'));
          // Dropdowns
          document.querySelectorAll('.dropdown-toggle').forEach(t => {
            t.addEventListener('click', e => {
              e.preventDefault();
              t.closest('.dropdown').classList.toggle('open');
            });
          });
          // Sticky nav
          window.addEventListener('scroll', () => {
            document.getElementById('navbar').classList.toggle('scrolled', window.scrollY > 50);
          });
          // FAQ
          document.querySelectorAll('.faq-q').forEach(q => {
            q.addEventListener('click', () => {
              const item = q.closest('.faq-item');
              item.classList.toggle('open');
            });
          });
        ` }} />
      </body>
    </html>
  );
}
