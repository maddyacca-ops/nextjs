import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Terms of Service | Home Sure Appliance Repair",
  description: "Terms of Service for Home Sure Appliance Repair.",
};
export default function TermsPage() {
  return (
    <div className="page-content" style={{paddingTop:'80px'}}>
      <h1>Terms of Service</h1>
      <p><strong>Last Updated:</strong> January 1, 2025</p>
      <p>By accessing or using the website https://homesureappliancerepair.us, you agree to be bound by these Terms of Service.</p>
      <h2>Services</h2>
      <p>Home Sure Appliance Repair provides appliance repair services throughout Texas. Service availability, pricing, and scheduling are subject to change without notice.</p>
      <h2>Disclaimers</h2>
      <p>While we strive for accuracy, we make no warranties regarding the completeness or accuracy of information on this website. Appliance repair results may vary based on the condition and age of your appliance.</p>
      <h2>Limitation of Liability</h2>
      <p>Home Sure Appliance Repair shall not be liable for any indirect, incidental, or consequential damages arising from the use of our services or website beyond the amount paid for the specific service in question.</p>
      <h2>Governing Law</h2>
      <p>These terms are governed by the laws of the State of Texas.</p>
      <h2>Contact</h2>
      <p>Questions? Contact us at <a href="mailto:info@homesureappliancerepair.us">info@homesureappliancerepair.us</a> or <a href="tel:8776701060">(877) 670-1060</a>.</p>
    </div>
  );
}
