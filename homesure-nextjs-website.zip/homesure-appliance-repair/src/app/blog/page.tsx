import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Appliance Repair Tips & Resources | Home Sure Blog",
  description: "Expert appliance repair tips for Texas homeowners. Troubleshooting guides, cost breakdowns, and maintenance advice for all major appliances.",
};

export default function BlogIndexPage() {
  return (
    <>
      <div className="page-hero" style={{height:'240px'}}>
        <div className="page-hero-overlay"/>
        <div className="page-hero-content">
          <div className="breadcrumb"><a href="/">Home</a> › Blog</div>
          <h1>Home Sure Blog: Expert Tips for Texas Homeowners</h1>
          <p>Appliance troubleshooting guides, cost breakdowns, and maintenance advice.</p>
        </div>
      </div>

      <section>
        <div className="section-inner">
          <div className="cards-grid">
        <div className="card">
          <img src="https://images.pexels.com/photos/33755641/pexels-photo-33755641.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Refrigerator Not Cooling in Texas Heat? Causes and Fixes" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">January 07, 2026 · 5 min read</p>
            <h3>Refrigerator Not Cooling in Texas Heat? Causes and Fixes</h3>
            <a href="/blog/refrigerator-not-cooling-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/3829560/pexels-photo-3829560.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Dishwasher Not Draining? Texas Troubleshooting Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">January 14, 2026 · 5 min read</p>
            <h3>Dishwasher Not Draining? Texas Troubleshooting Guide</h3>
            <a href="/blog/dishwasher-not-draining-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/8774376/pexels-photo-8774376.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Dryer Not Heating? Common Problems in Texas Homes" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">January 21, 2026 · 5 min read</p>
            <h3>Dryer Not Heating? Common Problems in Texas Homes</h3>
            <a href="/blog/dryer-not-heating-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/4119841/pexels-photo-4119841.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Oven Not Heating Evenly? Texas Homeowner Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">January 28, 2026 · 5 min read</p>
            <h3>Oven Not Heating Evenly? Texas Homeowner Guide</h3>
            <a href="/blog/oven-not-heating-evenly-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/8774444/pexels-photo-8774444.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Washer Not Spinning? Texas Troubleshooting Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">February 04, 2026 · 5 min read</p>
            <h3>Washer Not Spinning? Texas Troubleshooting Guide</h3>
            <a href="/blog/washer-not-spinning-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/3985071/pexels-photo-3985071.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Freezer Not Freezing? Texas Climate Troubleshooting Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">February 11, 2026 · 5 min read</p>
            <h3>Freezer Not Freezing? Texas Climate Troubleshooting Guide</h3>
            <a href="/blog/freezer-not-freezing-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/7285975/pexels-photo-7285975.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Ice Maker Not Making Ice? Texas Troubleshooting Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">February 18, 2026 · 5 min read</p>
            <h3>Ice Maker Not Making Ice? Texas Troubleshooting Guide</h3>
            <a href="/blog/ice-maker-not-making-ice-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/36085816/pexels-photo-36085816.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Gas Stove Not Igniting? Texas Troubleshooting Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">February 25, 2026 · 5 min read</p>
            <h3>Gas Stove Not Igniting? Texas Troubleshooting Guide</h3>
            <a href="/blog/gas-stove-not-igniting-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/29491360/pexels-photo-29491360.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Microwave Not Heating Food? Texas Troubleshooting Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">March 11, 2026 · 5 min read</p>
            <h3>Microwave Not Heating Food? Texas Troubleshooting Guide</h3>
            <a href="/blog/microwave-not-heating-texas" className="card-link">Read Article →</a>
          </div>
        </div>
        <div className="card">
          <img src="https://images.pexels.com/photos/27928761/pexels-photo-27928761.jpeg?auto=compress&cs=tinysrgb&w=800&auto=compress&cs=tinysrgb&w=800" alt="Washing Machine Not Draining? Texas Troubleshooting Guide" width="400" height="200" loading="lazy" />
          <div className="card-body">
            <p className="blog-date">March 23, 2026 · 5 min read</p>
            <h3>Washing Machine Not Draining? Texas Troubleshooting Guide</h3>
            <a href="/blog/washing-machine-not-draining-texas" className="card-link">Read Article →</a>
          </div>
        </div>
          </div>
        </div>
      </section>
    </>
  );
}
