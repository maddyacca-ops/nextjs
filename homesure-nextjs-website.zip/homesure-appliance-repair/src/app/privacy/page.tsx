import type { Metadata } from "next";
export const metadata: Metadata = {
  title: "Privacy Policy | Home Sure Appliance Repair",
  description: "Privacy Policy for Home Sure Appliance Repair — how we collect, use, and protect your information.",
};
export default function PrivacyPage() {
  return (
    <div className="page-content" style={{paddingTop:'80px'}}>
      <h1>Privacy Policy</h1>
      <p><strong>Last Updated:</strong> January 1, 2025</p>
      <p>Home Sure Appliance Repair ("we", "our", or "us") operates the website https://homesureappliancerepair.us. This Privacy Policy explains how we collect, use, disclose, and safeguard your information when you visit our website.</p>
      <h2>Information We Collect</h2>
      <p>We may collect information you provide when you call us or use our website, including name, phone number, email address, and service address. We also collect standard web analytics data such as IP addresses, browser type, and pages visited.</p>
      <h2>How We Use Your Information</h2>
      <p>We use collected information to schedule and perform appliance repair services, respond to inquiries, improve our website, and send service-related communications.</p>
      <h2>Information Sharing</h2>
      <p>We do not sell, trade, or otherwise transfer your personal information to third parties except as necessary to provide our services or as required by law.</p>
      <h2>Cookies</h2>
      <p>Our website may use cookies for analytics purposes. You can disable cookies in your browser settings without affecting your ability to use our website.</p>
      <h2>Contact Us</h2>
      <p>For privacy questions, contact us at <a href="mailto:info@homesureappliancerepair.us">info@homesureappliancerepair.us</a> or call <a href="tel:8776701060">(877) 670-1060</a>.</p>
    </div>
  );
}
