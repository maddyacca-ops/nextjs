export default function NotFound() {
  return (
    <div style={{textAlign:'center', padding:'120px 20px'}}>
      <div style={{fontSize:'6rem', marginBottom:'20px'}}>🔧</div>
      <h1 style={{fontFamily:'var(--font-display)', fontSize:'3rem', color:'var(--primary)', marginBottom:'16px'}}>Page Not Found</h1>
      <p style={{color:'var(--text-light)', fontSize:'1.1rem', marginBottom:'32px'}}>The page you're looking for doesn't exist. Let us help you find what you need.</p>
      <a href="/" style={{background:'var(--primary)', color:'white', padding:'14px 32px', borderRadius:'8px', fontWeight:700, fontSize:'1rem', textDecoration:'none', marginRight:'12px'}}>Go Home</a>
      <a href="tel:8776701060" style={{background:'var(--accent)', color:'white', padding:'14px 32px', borderRadius:'8px', fontWeight:700, fontSize:'1rem', textDecoration:'none'}}>📞 Call Now</a>
    </div>
  );
}
