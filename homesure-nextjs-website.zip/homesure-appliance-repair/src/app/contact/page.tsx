import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Contact Home Sure Appliance Repair | Texas | (877) 670-1060",
  description: "Contact Home Sure Appliance Repair for same-day appliance repair across Texas. Call (877) 670-1060 or email us. Available 7AM–9PM, 7 days a week.",
};

export default function ContactPage() {
  return (
    <>
      <div className="page-hero" style={{height:'240px'}}>
        <div className="page-hero-overlay"/>
        <div className="page-hero-content">
          <h1>Contact Home Sure Appliance Repair</h1>
          <p>We're available 7AM–9PM, 7 days a week across Texas.</p>
        </div>
      </div>

      <section>
        <div className="section-inner">
          <div className="contact-grid">
            <div>
              <h2>Get In Touch</h2>
              <p>For the fastest service, call us directly. Our dispatch team will connect you with a local Texas technician who can be at your home within hours.</p>

              <div className="cta-box">
  <h2>Call for Same-Day Service</h2>
  <p>Call Home Sure Appliance Repair for fast, reliable service across Texas. Free quotes, same-day appointments available.</p>
  <a href="tel:8776701060" className="cta-phone">📞 (877) 670-1060</a>
  <p className="cta-hours">Available 7AM–9PM · 7 Days a Week</p>
  <div className="cta-badges">
    <span className="cta-badge">✓ Free Quote</span>
    <span className="cta-badge">✓ Same-Day Service</span>
    <span className="cta-badge">✓ Licensed & Insured</span>
  </div>
</div>

              <div className="info-block" style={{marginTop:'32px'}}>
                <h3>Other Ways to Reach Us</h3>
                <div className="info-row">
                  <div className="info-icon">📧</div>
                  <div><strong>Email</strong><br/><a href="mailto:contact@homesureappliancerepair.us">contact@homesureappliancerepair.us</a></div>
                </div>
                <div className="info-row">
                  <div className="info-icon">📍</div>
                  <div><strong>Address</strong><br/>4521 Westview Drive, Austin, TX 78731</div>
                </div>
                <div className="info-row">
                  <div className="info-icon">⏰</div>
                  <div><strong>Hours</strong><br/>7AM–9PM, 7 Days a Week</div>
                </div>
              </div>
            </div>
            <div>
              <h2>Our Service Area</h2>
              <p>We serve all major Texas cities. Check our <a href="/cities">cities page</a> for complete coverage.</p>
              <iframe
  src="https://maps.google.com/maps?q=4521+Westview+Drive,+Austin,+TX+78731&output=embed&z=14"
  width="100%" height="420" style={{border:0,borderRadius:'8px'}}
  allowFullScreen loading="lazy"
  referrerPolicy="no-referrer-when-downgrade"
  title="Map"
></iframe>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
